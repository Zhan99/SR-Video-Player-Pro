# GitHub-এ SR Video Player Pro Build

Repo root-এ **SRVideoPlayerPro_GitHub.zip** রাখুন এবং **.github/workflows/build-apk.yml**-এ দেওয়া Workflow দিন। একই repo-তে অন্য Android Source ZIP থাকলে সরান। তারপর Commit → Actions → Build SR Video Player Pro APK → Run workflow। Build সফল হলে **Artifacts → SR-Video-Player-Pro-APK** থেকে app-debug.apk ডাউনলোড করুন।

`SR-Video-Player-Pro-main.zip` সুবিধার জন্য প্রস্তুত repo upload package। এটি সরাসরি একটিমাত্র ZIP হিসেবে repo root-এ আপলোড করবেন না; Extract করে ভিতরের দুই ফাইল তাদের সঠিক path-এ রাখবেন।
