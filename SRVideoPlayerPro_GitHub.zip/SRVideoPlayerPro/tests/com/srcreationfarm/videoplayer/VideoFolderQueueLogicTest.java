package com.srcreationfarm.videoplayer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Regression tests for same-folder Previous / Next playlist navigation. */
public final class VideoFolderQueueLogicTest {
    private static int assertions;
    private static void check(boolean value, String explanation) {
        assertions++;
        if (!value) throw new AssertionError(explanation);
    }
    private static VideoFolderQueueLogic.Entry clip(String key, String folder, String title, long date, long duration) {
        return new VideoFolderQueueLogic.Entry("content://media/video/" + key, title, folder, duration, date);
    }
    public static void main(String[] args) {
        List<VideoFolderQueueLogic.Entry> all = Arrays.asList(
            clip("4", "Movies/", "Fourth.mp4", 40, 600),
            clip("3", "Download/", "C.mp4", 30, 300),
            clip("2", "Movies/", "Second.mp4", 20, 900),
            clip("1", "Movies/", "First.mp4", 10, 100),
            clip("5", "DCIM/Camera/", "Camera.mp4", 50, 200),
            clip("6", "movies/", "Third.mp4", 35, 500));
        List<VideoFolderQueueLogic.Entry> movie = VideoFolderQueueLogic.filterAndOrder(all,"Movies", "", 0);
        check(movie.size()==4, "Only same-folder items should enter the queue");
        check(movie.get(0).uri.endsWith("/4"), "Newest video first");
        check(movie.get(1).uri.endsWith("/6"), "Second newest same-folder video");
        check(movie.get(2).uri.endsWith("/2"), "Third newest same-folder video");
        check(movie.get(3).uri.endsWith("/1"), "Oldest same-folder video");
        check(VideoFolderQueueLogic.indexOf(movie, "content://media/video/2") == 2,"Selected starts at exact correct index");
        check(VideoFolderQueueLogic.adjacentIndex(2,4,true)==3, "Next is following video");
        check(VideoFolderQueueLogic.adjacentIndex(2,4,false)==1, "Previous is preceding video");
        check(VideoFolderQueueLogic.adjacentIndex(0,4,false)==0, "First item does not leave folder");
        check(VideoFolderQueueLogic.adjacentIndex(3,4,true)==3, "Last item does not leave folder");
        check(VideoFolderQueueLogic.indexOf(movie,"content://media/video/3")==-1,"Other folder selection is rejected");
        List<VideoFolderQueueLogic.Entry> alpha=VideoFolderQueueLogic.filterAndOrder(all,"Movies", "",1);
        check(alpha.get(0).title.equals("First.mp4"),"Title A-Z start");
        check(alpha.get(1).title.equals("Fourth.mp4"),"Title A-Z second");
        check(alpha.get(2).title.equals("Second.mp4"),"Title A-Z third");
        check(alpha.get(3).title.equals("Third.mp4"),"Title A-Z fourth");
        List<VideoFolderQueueLogic.Entry> length=VideoFolderQueueLogic.filterAndOrder(all,"Movies", "",2);
        check(length.get(0).title.equals("Second.mp4"),"Longest video first");
        check(length.get(3).title.equals("First.mp4"),"Shortest video last");
        List<VideoFolderQueueLogic.Entry> filtered=VideoFolderQueueLogic.filterAndOrder(all,"Movies", "third",1);
        check(filtered.size()==1,"Search restricts queue to visible matches");
        check(filtered.get(0).uri.endsWith("/6"),"Search retains correct item");
        check(VideoFolderQueueLogic.filterAndOrder(all,"Movies", "no match",1).isEmpty(),"No matches returns empty");
        check(VideoFolderQueueLogic.filterAndOrder(all,"", "",0).isEmpty(),"Empty target folder is safe");
        check(VideoFolderQueueLogic.filterAndOrder(null,"Movies", "",0).isEmpty(),"Null list is safe");
        check(VideoFolderQueueLogic.filterAndOrder(Collections.emptyList(),"Movies", "",0).isEmpty(),"Empty list is safe");
        check(VideoFolderQueueLogic.indexOf(null,"abc")==-1,"Null list index safe");
        check(VideoFolderQueueLogic.indexOf(movie,null)==-1,"Null URI index safe");
        check(VideoFolderQueueLogic.adjacentIndex(0,0,true)==-1,"Empty queue navigation safe");
        check(VideoFolderQueueLogic.adjacentIndex(-1,4,true)==-1,"Invalid queue navigation safe");
        check(VideoFolderQueueLogic.adjacentIndex(4,4,false)==-1,"Too-large index navigation safe");
        // The selected index can be any position in a large queue (not limited to intent parcel size).
        List<VideoFolderQueueLogic.Entry> large=new ArrayList<>();
        for(int n=0;n<1500;n++) large.add(clip("large"+n,"Movies", "Clip"+n, n, n));
        List<VideoFolderQueueLogic.Entry> ordered=VideoFolderQueueLogic.filterAndOrder(large,"Movies", "",0);
        check(ordered.size()==1500,"Large folders are not silently truncated");
        check(VideoFolderQueueLogic.indexOf(ordered,"content://media/video/large750")==749,"Large folder selected index");
        check(VideoFolderQueueLogic.adjacentIndex(749,1500,true)==750,"Large folder next index");
        check(VideoFolderQueueLogic.adjacentIndex(749,1500,false)==748,"Large folder previous index");
        System.out.println("VideoFolderQueueLogicTest PASS: " + assertions + " assertions");
    }
}
