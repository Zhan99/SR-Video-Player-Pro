package com.srcreationfarm.videoplayer;

public final class VideoZoomLogicTest {
    private static int count;
    static void check(boolean pass, String text) {count++; if (!pass) throw new AssertionError(text);}
    public static void main(String[] args) {
        check(VideoZoomLogic.zoom(1,2)==2,"pinch zoom in");
        check(VideoZoomLogic.zoom(2,.5f)==1,"pinch zoom out");
        check(VideoZoomLogic.zoom(3,3)==4,"maximum zoom");
        check(VideoZoomLogic.zoom(1,.01f)==1,"minimum zoom");
        check(VideoZoomLogic.zoom(4,1)==4,"zoom remains");
        check(VideoZoomLogic.zoom(Float.NaN,2)==1,"NaN safe");
        check(VideoZoomLogic.zoom(2,Float.POSITIVE_INFINITY)==1,"infinite safe");
        check(VideoZoomLogic.zoom(2,0)==1,"zero multiplier safe");
        check(VideoZoomLogic.acceptedHoldSpeed(1.5f)==1.5f,"1.5 speed");
        check(VideoZoomLogic.acceptedHoldSpeed(2)==2,"2 speed");
        check(VideoZoomLogic.acceptedHoldSpeed(2.5f)==2.5f,"2.5 speed");
        check(VideoZoomLogic.acceptedHoldSpeed(3)==3,"3 speed");
        check(VideoZoomLogic.acceptedHoldSpeed(4)==4,"4 speed");
        check(VideoZoomLogic.acceptedHoldSpeed(25)==2,"invalid fallback");
        check(VideoZoomLogic.acceptedHoldSpeed(Float.NaN)==2,"NaN speed fallback");
        check(VideoZoomLogic.canStartHold(false,false,true,true),"hold allowed");
        check(!VideoZoomLogic.canStartHold(true,false,true,true),"lock blocks hold");
        check(!VideoZoomLogic.canStartHold(false,true,true,true),"pinch blocks hold");
        check(!VideoZoomLogic.canStartHold(false,false,false,true),"paused blocks hold");
        check(!VideoZoomLogic.canStartHold(false,false,true,false),"no video blocks hold");
        System.out.println(count+" video zoom/hold gesture tests passed");
    }
}
