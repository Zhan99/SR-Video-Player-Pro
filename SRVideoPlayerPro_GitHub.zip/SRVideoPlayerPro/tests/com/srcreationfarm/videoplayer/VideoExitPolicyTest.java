package com.srcreationfarm.videoplayer;

public final class VideoExitPolicyTest {
    private static void verify(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }

    public static void main(String[] args) {
        verify(VideoExitPolicy.shouldStopPlayback(false), "Back exits and stops video/audio");
        verify(!VideoExitPolicy.shouldStopPlayback(true), "Music icon keeps background audio");
        verify(VideoExitPolicy.canKeepAudio(true), "Current video permits background audio");
        verify(!VideoExitPolicy.canKeepAudio(false), "No video must remain in player");
        verify(VideoExitPolicy.mayAutoEnterPictureInPicture(false), "Normal home exit may use PiP");
        verify(!VideoExitPolicy.mayAutoEnterPictureInPicture(true), "Explicit stop/audio exit must not enter PiP");
        System.out.println("VideoExitPolicyTest: 6 checks PASS");
    }
}
