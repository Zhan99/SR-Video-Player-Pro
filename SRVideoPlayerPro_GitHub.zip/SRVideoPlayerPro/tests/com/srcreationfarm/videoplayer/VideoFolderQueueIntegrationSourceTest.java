package com.srcreationfarm.videoplayer;

import java.nio.file.Files;
import java.nio.file.Path;

/** Integration regression: folder extra -> worker queue -> selected Media3 item. */
public final class VideoFolderQueueIntegrationSourceTest {
    private static int checks;
    private static void check(boolean value, String msg) {
        checks++;
        if (!value) throw new AssertionError(msg);
    }
    public static void main(String[] args) throws Exception {
        if (args.length != 1) throw new AssertionError("Usage: <source-java-root>");
        Path dir = Path.of(args[0]);
        String library = Files.readString(dir.resolve("VideoLibraryActivity.java"));
        String player = Files.readString(dir.resolve("VideoPlayerActivity.java"));
        String loader = Files.readString(dir.resolve("VideoFolderPlaylistLoader.java"));
        String queue = Files.readString(dir.resolve("VideoFolderQueueLogic.java"));
        check(library.contains("mode == MODE_FOLDER_VIDEOS && selectedFolder != null"),"Folder-only context");
        check(library.contains("putExtra(VideoPlayerActivity.EXTRA_FOLDER_PATH"),"Folder key sent");
        check(library.contains("putExtra(VideoPlayerActivity.EXTRA_FOLDER_SORT"),"Sort mode sent");
        check(library.contains("putExtra(VideoPlayerActivity.EXTRA_FOLDER_SEARCH"),"Search sent");
        check(!library.contains("putStringArrayListExtra(VideoPlayerActivity.EXTRA_FOLDER_PATH"),"No massive Intent parcel");
        check(player.contains("playFolderSelection(uri, title, folderPath"),"Player starts queue when opened from folder");
        check(player.contains("folderQueueWorker.execute"),"Folder query off main thread");
        check(player.contains("VideoFolderPlaylistLoader.readFolder"),"MediaStore queue loader wired");
        check(player.contains("VideoFolderQueueLogic.indexOf"),"Selected item index detected");
        check(player.contains("playItems(items, currentIndex)"),"Selected video starts in playlist");
        check(player.contains("controller.setMediaItems(items, index, start)"),"Media3 sets the full queue at chosen item");
        check(player.contains("pendingItemIndex = index"),"Selected index survives service reconnect");
        check(player.contains("controller.seekToPreviousMediaItem()"),"Previous button skips backward");
        check(player.contains("controller.seekToNextMediaItem()"),"Next button skips forward");
        check(player.contains("previousVideoButton.setContentDescription"),"Accessible previous button");
        check(player.contains("nextVideoButton.setContentDescription"),"Accessible next button");
        check(player.contains("VideoFreshnessStore.markViewed(VideoPlayerActivity.this, started.toString())"),"NEW badge updated on auto transition");
        check(loader.contains("MediaStore.Video.Media.DATE_ADDED"),"MediaStore date ordering");
        check(loader.contains("VideoFolderLogic.sameFolder(folder, currentFolder)"),"Folder path matching");
        check(queue.contains("filterAndOrder"),"Sort/filter policy exists");
        System.out.println("VideoFolderQueueIntegrationSourceTest PASS: "+checks+" assertions");
    }
}
