package com.srcreationfarm.videoplayer;

public final class VideoResumeLogicTest {
    private static int count;
    private static void check(boolean ok, String message) {
        count++;
        if (!ok) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        String one = "content://media/external/video/media/11";
        String two = "content://media/external/video/media/12";
        check(VideoResumeLogic.keyForUri(one).equals(VideoResumeLogic.keyForUri(one)), "stable key");
        check(!VideoResumeLogic.keyForUri(one).equals(VideoResumeLogic.keyForUri(two)), "independent videos");
        check(VideoResumeLogic.keyForUri(one).startsWith("video.position."), "key namespace");
        check(!VideoResumeLogic.shouldResume(9_999L, 300_000L), "short start not resumed");
        check(VideoResumeLogic.shouldResume(50_000L, 300_000L), "midpoint resumed");
        check(!VideoResumeLogic.shouldResume(290_000L, 300_000L), "near end not resumed");
        check(VideoResumeLogic.shouldResume(50_000L, -1L), "unknown duration resume");
        check(VideoResumeLogic.positionToSave(60_000L, 300_000L, false)==60_000L, "position retained");
        check(VideoResumeLogic.positionToSave(299_000L, 300_000L, false)==0L, "near end reset");
        check(VideoResumeLogic.positionToSave(50_000L, 300_000L, true)==0L, "ended reset");
        check(VideoResumeLogic.positionToSave(-5L, -1L, false)==0L, "negative reset");
        check(VideoResumeLogic.positionToSave(50_000L, -1L, false)==50_000L, "unknown duration saved");
        System.out.println("VideoResumeLogicTest: " + count + " checks PASS");
    }
}
