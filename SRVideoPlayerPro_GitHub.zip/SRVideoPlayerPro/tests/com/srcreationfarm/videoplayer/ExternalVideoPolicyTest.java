package com.srcreationfarm.videoplayer;
public final class ExternalVideoPolicyTest {
    private static int checked;
    private static void assertTrue(boolean condition, String label) {
        checked++;if(!condition) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        assertTrue(ExternalVideoPolicy.playableScheme("content"),"DocumentsProvider URI");
        assertTrue(ExternalVideoPolicy.playableScheme("CONTENT"),"case insensitive content");
        assertTrue(ExternalVideoPolicy.playableScheme("file"),"File Manager file URI");
        assertTrue(ExternalVideoPolicy.playableScheme("https"),"HTTPS video link");
        assertTrue(ExternalVideoPolicy.playableScheme("rtsp"),"RTSP stream");
        assertTrue(!ExternalVideoPolicy.playableScheme("javascript"),"reject unsafe scheme");
        assertTrue(!ExternalVideoPolicy.playableScheme("intent"),"reject intent scheme");
        assertTrue(!ExternalVideoPolicy.playableScheme(null),"null scheme");
        assertTrue(ExternalVideoPolicy.safeVideoMime("video/mp4"),"MP4");
        assertTrue(ExternalVideoPolicy.safeVideoMime("video/x-matroska"),"MKV video");
        assertTrue(ExternalVideoPolicy.safeVideoMime("application/x-matroska"),"MKV app MIME");
        assertTrue(ExternalVideoPolicy.safeVideoMime("application/octet-stream"),"unknown provider MIME");
        assertTrue(ExternalVideoPolicy.safeVideoMime("application/vnd.apple.mpegurl"),"HLS");
        assertTrue(ExternalVideoPolicy.safeVideoMime("application/dash+xml"),"DASH manifest");
        assertTrue(ExternalVideoPolicy.safeVideoMime("application/x-mpegURL"),"HLS playlist");
        assertTrue(ExternalVideoPolicy.safeVideoMime("application/vnd.ms-sstr+xml"),"Smooth Streaming");
        assertTrue(!ExternalVideoPolicy.safeVideoMime("image/png"),"not an image player");
        assertTrue(!ExternalVideoPolicy.safeVideoMime(null),"null MIME");
        System.out.println("ExternalVideoPolicyTest: "+checked+" tests PASS");
    }
}
