package com.srcreationfarm.videoplayer;

import com.sun.source.tree.ClassTree;
import com.sun.source.tree.CompilationUnitTree;
import com.sun.source.tree.Tree;
import com.sun.source.tree.VariableTree;
import com.sun.source.util.JavacTask;

import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;

/** Tests actual Java AST fields without requiring android.jar or Gradle. */
public final class VideoLibrarySourceFieldsTest {
    private static void require(boolean valid, String what) {
        if (!valid) throw new AssertionError(what);
    }
    public static void main(String[] args) throws IOException {
        require(args.length == 1, "Expected VideoLibraryActivity.java path");
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        require(compiler != null, "JDK compiler API is required");
        try (StandardJavaFileManager fm = compiler.getStandardFileManager(null, null, null)) {
            Iterable<? extends JavaFileObject> sources = fm.getJavaFileObjects(Path.of(args[0]).toFile());
            JavacTask task = (JavacTask) compiler.getTask(null, fm, null,
                    List.of("-proc:none", "-source", "17"), null, sources);
            Map<String, String> members = new HashMap<>();
            for (CompilationUnitTree unit : task.parse()) {
                for (Tree declaration : unit.getTypeDecls()) {
                    if (!(declaration instanceof ClassTree)) continue;
                    ClassTree clazz = (ClassTree) declaration;
                    if (!clazz.getSimpleName().contentEquals("VideoLibraryActivity")) continue;
                    for (Tree member : clazz.getMembers()) {
                        if (member instanceof VariableTree) {
                            VariableTree field = (VariableTree) member;
                            members.put(field.getName().toString(), field.getType().toString());
                        }
                    }
                }
            }
            require("TextView".equals(members.get("status")), "Missing TextView status field");
            require("VideoAdapter".equals(members.get("adapter")), "Missing VideoAdapter adapter field");
            require("VideoFolderAdapter".equals(members.get("folderAdapter")),
                    "Missing folderAdapter field");
            require("VideoFolderGridAdapter".equals(members.get("folderGridAdapter")),
                    "Missing folderGridAdapter field");
            require("ListView".equals(members.get("list")), "Missing ListView field");
            require("GridView".equals(members.get("folderGrid")), "Missing GridView field");
            require("VideoThumbnailLoader".equals(members.get("thumbnails")),
                    "Missing async VideoThumbnailLoader field");
            require("TextView".equals(members.get("continueButton")),
                    "Missing floating continue playback button field");
        }
        System.out.println("VideoLibraryActivity AST field regression test passed (8 declarations)");
    }
}
