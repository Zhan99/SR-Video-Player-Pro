package com.srcreationfarm.videoplayer;

public final class VideoPlayerLogicTest {
    public static void main(String[] args) {
        check("application/x-subrip".equals(VideoPlayerLogic.subtitleMimeType("captions.SRT")), "SRT MIME");
        check("text/vtt".equals(VideoPlayerLogic.subtitleMimeType("captions.vtt")), "VTT MIME");
        check("text/x-ssa".equals(VideoPlayerLogic.subtitleMimeType("captions.ass")), "ASS MIME");
        check("text/x-ssa".equals(VideoPlayerLogic.subtitleMimeType("captions.ssa")), "SSA MIME");
        check("application/ttml+xml".equals(VideoPlayerLogic.subtitleMimeType("captions.ttml")), "TTML MIME");
        check(VideoPlayerLogic.subtitleMimeType("captions.txt") == null, "unsupported subtitle");
        check(VideoPlayerLogic.isNetworkUrl("https://example.com/video.mp4"), "HTTPS URL");
        check(!VideoPlayerLogic.isNetworkUrl("http://media.example.org/live.m3u8"), "insecure HTTP URL rejected");
        check(VideoPlayerLogic.isNetworkUrl("rtsp://camera.example.org/live"), "RTSP URL");
        check(!VideoPlayerLogic.isNetworkUrl("file:///storage/video.mp4"), "file URI rejected as network");
        check(!VideoPlayerLogic.isNetworkUrl("javascript:alert(1)"), "javascript URL rejected");
        check(!VideoPlayerLogic.isNetworkUrl("https://"), "invalid host rejected");
        check("movie.m3u8".equals(VideoPlayerLogic.titleFromUrl("https://cdn.example.com/movie.m3u8")), "URL title");
        System.out.println("VideoPlayerLogicTest: 13 checks PASS");
    }

    private static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }
}
