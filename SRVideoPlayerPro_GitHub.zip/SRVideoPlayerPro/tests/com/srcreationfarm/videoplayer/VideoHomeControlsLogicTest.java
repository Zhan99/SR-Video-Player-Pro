package com.srcreationfarm.videoplayer;

public final class VideoHomeControlsLogicTest {
    private static int checks;
    private static void equal(Object expected, Object actual) {
        checks++;
        if (!expected.equals(actual)) throw new AssertionError("Expected " + expected + ", got " + actual);
    }
    private static void ok(boolean value) {
        checks++;
        if (!value) throw new AssertionError("Expected true");
    }
    public static void main(String[] args) {
        ok(!VideoHomeControlsLogic.hasLastVideo(null));
        ok(!VideoHomeControlsLogic.hasLastVideo(""));
        ok(!VideoHomeControlsLogic.hasLastVideo("  "));
        ok(VideoHomeControlsLogic.hasLastVideo("content://media/a"));
        equal("00:00", VideoHomeControlsLogic.timeLabel(0));
        equal("00:00", VideoHomeControlsLogic.timeLabel(-999));
        equal("00:01", VideoHomeControlsLogic.timeLabel(1900));
        equal("01:02", VideoHomeControlsLogic.timeLabel(62000));
        equal("1:01:01", VideoHomeControlsLogic.timeLabel(3661000));
        equal("▶  Resume Last Video · Play a video first",
              VideoHomeControlsLogic.resumeLabel("unused", 12345, false));
        equal("▶  Resume · Clip.mp4 · 01:35",
              VideoHomeControlsLogic.resumeLabel("Clip.mp4", 95000, true));
        equal("▶  Resume · Last watched video · 00:00",
              VideoHomeControlsLogic.resumeLabel(" ", 0, true));
        ok(VideoHomeControlsLogic.resumeLabel("a".repeat(100), 0, true).length() < 100);
        ok(!VideoHomeControlsLogic.resumeLabel("line\nbreak", 0, true).contains("\n"));
        System.out.println("VideoHomeControlsLogicTest: " + checks + " checks PASS");
    }
}
