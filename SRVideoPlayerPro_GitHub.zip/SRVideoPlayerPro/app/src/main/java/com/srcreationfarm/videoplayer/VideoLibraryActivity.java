package com.srcreationfarm.videoplayer;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.ContentObserver;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.GridView;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.PopupMenu;
import android.content.SharedPreferences;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Phone video library. MediaStore indexes local, shared-storage videos with user consent. */
public class VideoLibraryActivity extends Activity {
    private static final int REQUEST_VIDEO_ACCESS = 5071;
    private final ExecutorService loader = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<VideoRow> allVideos = new ArrayList<>();
    private final List<VideoRow> visibleVideos = new ArrayList<>();
    private final List<FolderSummary> folderItems = new ArrayList<>();
    private final List<FolderSummary> visibleFolders = new ArrayList<>();
    // Keep the video adapter and status view as Activity fields. The folder/list,
    // permission, and MediaStore callbacks use these across several methods.
    private VideoAdapter adapter;
    private TextView status;
    private VideoThumbnailLoader thumbnails;
    private TextView continueButton;
    private VideoFolderAdapter folderAdapter;
    private VideoFolderGridAdapter folderGridAdapter;
    private ListView list;
    private GridView folderGrid;
    private TextView heading;
    private TextView gridToggle;
    private Spinner sortSpinner;
    private EditText search;
    private String selectedFolder;
    private int mode = MODE_FOLDERS;
    private boolean gridMode;
    private boolean searchVisible;
    private static final int MODE_FOLDERS = 0;
    private static final int MODE_ALL = 1;
    private static final int MODE_FOLDER_VIDEOS = 2;
    private static final int MODE_CONTINUE = 3;
    private int loadNumber;
    private boolean firstResume = true;
    private boolean destroyed;
    private boolean observerRegistered;
    private final Runnable videoIndexChanged = () -> {
        if (!destroyed && hasVideoPermission()) reloadVideos();
    };
    private final ContentObserver mediaChanges = new ContentObserver(main) {
        @Override public void onChange(boolean selfChange) {
            main.removeCallbacks(videoIndexChanged);
            main.postDelayed(videoIndexChanged, 850L);
        }
    };

    @Override protected void onCreate(Bundle state) {
        ThemeManager.applyToActivity(this);
        super.onCreate(state);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        thumbnails = new VideoThumbnailLoader(getContentResolver());
        buildUi();
        if (hasVideoPermission()) reloadVideos();
        else askForVideoAccess();
    }

    /** Launcher: show video folders immediately. Other tools live under the 3-dot menu. */
    private void buildUi() {
        gridMode = getSharedPreferences("sr_video_library_ui", MODE_PRIVATE)
                .getBoolean("folder_grid", false);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(dp(12), dp(7), dp(12), dp(6));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = label("‹", 34, Ui.TEXT, true);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Back to video folders");
        back.setOnClickListener(v -> navigateBack());
        toolbar.addView(back, new LinearLayout.LayoutParams(dp(42), dp(54)));
        heading = label("Video Folders", 22, Ui.TEXT, true);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.addView(heading, new LinearLayout.LayoutParams(0, dp(54), 1));
        TextView menu = iconAction("⋮", "All video player functions and settings");
        menu.setOnClickListener(v -> showThreeDotMenu(menu));
        toolbar.addView(menu, new LinearLayout.LayoutParams(dp(48), dp(54)));
        root.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(58)));

        // A dedicated visible Play button for the last watched video and exact bookmark.
        continueButton = label("▶  Resume Last Video", 16, Color.WHITE, true);
        int accentLuma = (Color.red(Ui.ACCENT) * 299 + Color.green(Ui.ACCENT) * 587
                + Color.blue(Ui.ACCENT) * 114) / 1000;
        continueButton.setTextColor(accentLuma > 150 ? 0xFF101820 : Color.WHITE);
        continueButton.setGravity(Gravity.CENTER_VERTICAL);
        continueButton.setSingleLine(true);
        continueButton.setEllipsize(TextUtils.TruncateAt.END);
        continueButton.setPadding(dp(17), 0, dp(12), 0);
        GradientDrawable resumeBackground = new GradientDrawable();
        resumeBackground.setCornerRadius(dp(15));
        resumeBackground.setColor(Ui.ACCENT);
        continueButton.setBackground(resumeBackground);
        continueButton.setElevation(dp(4));
        continueButton.setOnClickListener(v -> continueLastVideo());
        LinearLayout.LayoutParams resumeParams = new LinearLayout.LayoutParams(-1, dp(62));
        resumeParams.topMargin = dp(3);
        resumeParams.bottomMargin = dp(11);
        root.addView(continueButton, resumeParams);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(15);
        search.setTextColor(Ui.TEXT);
        search.setHintTextColor(Ui.MUTED);
        search.setHint("Search folders and videos");
        search.setPadding(dp(14), dp(7), dp(14), dp(7));
        search.setBackground(background(Ui.CARD));
        search.setVisibility(View.GONE);
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(-1, dp(49));
        searchParams.bottomMargin = dp(8);
        root.addView(search, searchParams);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int before, int count) { applyFilters(); }
            @Override public void afterTextChanged(Editable value) {}
        });

        LinearLayout filterLine = new LinearLayout(this);
        filterLine.setGravity(Gravity.CENTER_VERTICAL);
        status = label("Checking video access…", 12, Ui.MUTED, false);
        filterLine.addView(status, new LinearLayout.LayoutParams(-1, dp(39)));
        // Existing sort choices are preserved, but controlled from the 3-dot menu.
        sortSpinner = new Spinner(this);
        sortSpinner.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Newest", "Name A–Z", "Longest"}));
        sortSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                applyFilters();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        int savedSort = getSharedPreferences("sr_video_library_ui", MODE_PRIVATE)
                .getInt("sort_order", 0);
        sortSpinner.setSelection(Math.max(0, Math.min(2, savedSort)));
        root.addView(filterLine, new LinearLayout.LayoutParams(-1, dp(39)));

        FrameLayout browseArea = new FrameLayout(this);
        list = new ListView(this);
        list.setDividerHeight(dp(5));
        list.setDivider(null);
        list.setBackgroundColor(Color.TRANSPARENT);
        list.setCacheColorHint(Color.TRANSPARENT);
        list.setVerticalScrollBarEnabled(true);
        adapter = new VideoAdapter();
        folderAdapter = new VideoFolderAdapter();
        folderGridAdapter = new VideoFolderGridAdapter();
        browseArea.addView(list, new FrameLayout.LayoutParams(-1, -1));
        list.setOnItemClickListener((parent, view, position, id) -> {
            if (mode == MODE_FOLDERS) openFolder(visibleFolders.get(position).path);
            else openVideo(visibleVideos.get(position), false);
        });
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            if (mode == MODE_FOLDERS) return false;
            showVideoOptions(visibleVideos.get(position));
            return true;
        });
        folderGrid = new GridView(this);
        folderGrid.setNumColumns(2);
        folderGrid.setHorizontalSpacing(dp(10));
        folderGrid.setVerticalSpacing(dp(10));
        folderGrid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        folderGrid.setClipToPadding(false);
        folderGrid.setAdapter(folderGridAdapter);
        folderGrid.setOnItemClickListener((parent, view, position, id) ->
                openFolder(visibleFolders.get(position).path));
        browseArea.addView(folderGrid, new FrameLayout.LayoutParams(-1, -1));
        root.addView(browseArea, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        switchMode(MODE_FOLDERS);
    }

    private static final int MENU_FOLDERS = 1;
    private static final int MENU_ALL_VIDEOS = 2;
    private static final int MENU_CONTINUE = 3;
    private static final int MENU_OPEN_VIDEO = 4;
    private static final int MENU_SEARCH = 5;
    private static final int MENU_SORT = 6;
    private static final int MENU_GRID = 7;
    private static final int MENU_REFRESH = 8;
    private static final int MENU_SETTINGS = 9;
    private static final int MENU_FAVORITES = 10;
    private static final int MENU_HISTORY = 11;
    private static final int MENU_NETWORK = 12;

    private void showThreeDotMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add(0, MENU_FOLDERS, 0, "📁  Video folders");
        popup.getMenu().add(0, MENU_ALL_VIDEOS, 1, "🎞  All videos");
        popup.getMenu().add(0, MENU_CONTINUE, 2, "↺  Continue watching list");
        popup.getMenu().add(0, MENU_OPEN_VIDEO, 3, "＋  Open a video file");
        popup.getMenu().add(0, MENU_FAVORITES, 4, "★  Favorite videos");
        popup.getMenu().add(0, MENU_HISTORY, 5, "◷  Playback history");
        popup.getMenu().add(0, MENU_NETWORK, 6, "🌐  Play HTTPS / RTSP link");
        popup.getMenu().add(0, MENU_SEARCH, 7, "⌕  Search folders / videos");
        popup.getMenu().add(0, MENU_SORT, 8, "⇅  Sort videos");
        popup.getMenu().add(0, MENU_GRID, 9, gridMode ? "☷  Folder list view" : "▦  Folder grid view");
        popup.getMenu().add(0, MENU_REFRESH, 10, "↻  Refresh video library");
        popup.getMenu().add(0, MENU_SETTINGS, 11, "⚙  Settings & more");
        popup.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case MENU_FOLDERS: switchMode(MODE_FOLDERS); break;
                case MENU_ALL_VIDEOS: switchMode(MODE_ALL); break;
                case MENU_CONTINUE: switchMode(MODE_CONTINUE); break;
                case MENU_OPEN_VIDEO: openVideoPicker(); break;
                case MENU_FAVORITES: showSavedVideos("favorites", "Favorite videos"); break;
                case MENU_HISTORY: showSavedVideos("history", "Playback history"); break;
                case MENU_NETWORK: showNetworkUrlDialog(); break;
                case MENU_SEARCH: toggleSearch(); break;
                case MENU_SORT: showSortDialog(); break;
                case MENU_GRID:
                    gridMode = !gridMode;
                    getSharedPreferences("sr_video_library_ui", MODE_PRIVATE).edit()
                            .putBoolean("folder_grid", gridMode).apply();
                    updateViewMode();
                    break;
                case MENU_REFRESH: reloadOrRequest(); break;
                case MENU_SETTINGS: showSettingsMenu(); break;
                default: return false;
            }
            return true;
        });
        popup.show();
    }

    private void openVideoPicker() {
        Intent intent = new Intent(this, VideoPlayerActivity.class);
        intent.putExtra(VideoPlayerActivity.EXTRA_OPEN_PICKER, true);
        startActivity(intent);
    }

    /** Reuse the same private bookmark collections as the playback screen. */
    private void showSavedVideos(String key, String title) {
        Set<String> values = getSharedPreferences("sr_video_player", MODE_PRIVATE)
                .getStringSet(key, Collections.emptySet());
        if (values == null || values.isEmpty()) {
            Toast.makeText(this, "No " + title.toLowerCase(Locale.ROOT) + " yet", Toast.LENGTH_SHORT).show();
            return;
        }
        List<String> uris = new ArrayList<>(values);
        String[] labels = new String[uris.size()];
        for (int i = 0; i < uris.size(); i++) {
            Uri uri = Uri.parse(uris.get(i));
            String name = uri.getLastPathSegment();
            for (VideoRow row : allVideos) {
                if (row.uri.toString().equals(uris.get(i))) { name = row.title; break; }
            }
            labels[i] = name == null || name.trim().isEmpty() ? "Video " + (i + 1) : name;
        }
        new AlertDialog.Builder(this).setTitle(title)
                .setItems(labels, (dialog, index) -> {
                    Intent intent = new Intent(this, VideoPlayerActivity.class);
                    intent.putExtra(VideoPlayerActivity.EXTRA_VIDEO_URI, uris.get(index));
                    intent.putExtra(VideoPlayerActivity.EXTRA_VIDEO_TITLE, labels[index]);
                    startActivity(intent);
                }).setNegativeButton("Close", null).show();
    }

    private void showNetworkUrlDialog() {
        EditText entry = new EditText(this);
        entry.setSingleLine(true);
        entry.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        entry.setHint("https://example.com/video.m3u8");
        new AlertDialog.Builder(this).setTitle("Open HTTPS / RTSP video")
                .setView(entry).setPositiveButton("Play", (dialog, which) -> {
                    String url = entry.getText().toString().trim();
                    if (!VideoPlayerLogic.isNetworkUrl(url)) {
                        Toast.makeText(this, "Enter a valid HTTPS or RTSP URL", Toast.LENGTH_LONG).show();
                        return;
                    }
                    Intent intent = new Intent(this, VideoPlayerActivity.class);
                    intent.putExtra(VideoPlayerActivity.EXTRA_VIDEO_URI, url);
                    intent.putExtra(VideoPlayerActivity.EXTRA_VIDEO_TITLE,
                            VideoPlayerLogic.titleFromUrl(url));
                    startActivity(intent);
                }).setNegativeButton("Cancel", null).show();
    }

    private void toggleSearch() {
        searchVisible = !searchVisible;
        search.setVisibility(searchVisible ? View.VISIBLE : View.GONE);
        if (searchVisible) search.requestFocus();
        else search.setText("");
    }

    private void showSortDialog() {
        String[] options = {"Newest first", "Name A–Z", "Longest first"};
        int current = sortSpinner == null ? 0 : sortSpinner.getSelectedItemPosition();
        new AlertDialog.Builder(this).setTitle("Sort videos")
                .setSingleChoiceItems(options, current, (dialog, which) -> {
                    sortSpinner.setSelection(which);
                    getSharedPreferences("sr_video_library_ui", MODE_PRIVATE).edit()
                            .putInt("sort_order", which).apply();
                    applyFilters();
                    dialog.dismiss();
                }).setNegativeButton("Cancel", null).show();
    }

    private void showSettingsMenu() {
        String[] options = {"🎨  Appearance, Premium / Classic & UI sound",
                "⏩  Hold-to-Fast playback speed", "⭐  Default video player help",
                "ℹ  About Developer"};
        new AlertDialog.Builder(this).setTitle("SR Video Player Pro · Settings")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) startActivity(new Intent(this, ThemeSettingsActivity.class));
                    else if (which == 1) showHoldSpeedDialog();
                    else if (which == 2) showDefaultHelp();
                    else startActivity(new Intent(this, AboutDeveloperActivity.class));
                }).setNegativeButton("Close", null).show();
    }

    private void showHoldSpeedDialog() {
        float[] speeds = VideoGestureSettings.OPTIONS;
        String[] options = new String[speeds.length];
        int checked = 1;
        float current = VideoGestureSettings.holdSpeed(this);
        for (int i = 0; i < speeds.length; i++) {
            options[i] = speeds[i] + "×";
            if (Math.abs(speeds[i] - current) < .01f) checked = i;
        }
        new AlertDialog.Builder(this).setTitle("Hold screen to fast-forward")
                .setSingleChoiceItems(options, checked, (dialog, which) -> {
                    VideoGestureSettings.saveHoldSpeed(this, speeds[which]);
                    Toast.makeText(this, "Hold-to-Fast: " + speeds[which] + "×", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                }).setNegativeButton("Cancel", null).show();
    }

    private void showDefaultHelp() {
        new AlertDialog.Builder(this).setTitle("Default video player")
                .setMessage("File Manager / Gallery থেকে একটি ভিডিও খুলে Open with → SR Video Player Pro → Always বেছে নিন, যদি ফোনে Always অপশন থাকে।")
                .setPositiveButton("App settings", (dialog, which) -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + getPackageName())));
                    } catch (RuntimeException e) {
                        startActivity(new Intent(Settings.ACTION_SETTINGS));
                    }
                }).setNegativeButton("Close", null).show();
    }

    private TextView iconAction(String icon, String description) {
        TextView action = label(icon, 25, Ui.TEXT, true);
        action.setGravity(Gravity.CENTER);
        action.setContentDescription(description);
        action.setClickable(true);
        return action;
    }

    private void openFolder(String path) {
        selectedFolder = path;
        switchMode(MODE_FOLDER_VIDEOS);
    }

    private void switchMode(int target) {
        mode = target;
        if (mode != MODE_FOLDER_VIDEOS) selectedFolder = null;
        if (heading != null) {
            String title = mode == MODE_FOLDERS ? "Video Folders" : mode == MODE_ALL ? "All Videos" :
                    mode == MODE_CONTINUE ? "Continue Watching" : VideoFolderLogic.displayName(selectedFolder);
            heading.setText(title);
        }
        updateViewMode();
        applyFilters();
        updateContinueButton();
    }

    private void updateViewMode() {
        boolean foldersScreen = mode == MODE_FOLDERS;
        if (gridToggle != null) gridToggle.setVisibility(foldersScreen ? View.VISIBLE : View.INVISIBLE);
        if (list != null) {
            list.setAdapter(foldersScreen ? folderAdapter : adapter);
            list.setVisibility(!foldersScreen || !gridMode ? View.VISIBLE : View.GONE);
        }
        if (folderGrid != null) folderGrid.setVisibility(foldersScreen && gridMode ? View.VISIBLE : View.GONE);
    }

    private void navigateBack() {
        if (mode == MODE_FOLDER_VIDEOS || mode == MODE_ALL || mode == MODE_CONTINUE) {
            switchMode(MODE_FOLDERS);
        } else finish();
    }

    @Override public void onBackPressed() {
        if (mode != MODE_FOLDERS) navigateBack();
        else super.onBackPressed();
    }

    private void openVideo(VideoRow video, boolean restart) {
        Intent intent = new Intent(this, VideoPlayerActivity.class);
        intent.putExtra(VideoPlayerActivity.EXTRA_VIDEO_URI, video.uri.toString());
        intent.putExtra(VideoPlayerActivity.EXTRA_VIDEO_TITLE, video.title);
        intent.putExtra(VideoPlayerActivity.EXTRA_RESTART_VIDEO, restart);
        // Only when entering an actual folder: queue every matching video in THAT folder.
        // Send only folder metadata, not a huge URI array that could overflow Android's Intent limit.
        if (mode == MODE_FOLDER_VIDEOS && selectedFolder != null) {
            intent.putExtra(VideoPlayerActivity.EXTRA_FOLDER_PATH, VideoFolderLogic.folderKey(selectedFolder));
            intent.putExtra(VideoPlayerActivity.EXTRA_FOLDER_SORT,
                    sortSpinner == null ? 0 : sortSpinner.getSelectedItemPosition());
            intent.putExtra(VideoPlayerActivity.EXTRA_FOLDER_SEARCH,
                    search == null ? "" : search.getText().toString());
        }
        startActivity(intent);
    }

    private void continueLastVideo() {
        SharedPreferences prefs = getSharedPreferences("sr_video_player", MODE_PRIVATE);
        String uri = prefs.getString("last_uri", null);
        if (uri == null || uri.trim().isEmpty()) {
            Toast.makeText(this, "এখনো কোনো ভিডিও চালানো হয়নি।", Toast.LENGTH_SHORT).show();
            updateContinueButton();
            return;
        }
        Intent intent = new Intent(this, VideoPlayerActivity.class);
        intent.putExtra(VideoPlayerActivity.EXTRA_CONTINUE_LAST, true);
        startActivity(intent);
    }

    private void updateContinueButton() {
        if (continueButton == null) return;
        SharedPreferences prefs = getSharedPreferences("sr_video_player", MODE_PRIVATE);
        String uri = prefs.getString("last_uri", null);
        boolean hasLast = VideoHomeControlsLogic.hasLastVideo(uri);
        String title = prefs.getString("last_title", "Last played video");
        long progress = Math.max(0L, prefs.getLong("last_position", 0L));
        continueButton.setVisibility(View.VISIBLE);
        continueButton.setText(VideoHomeControlsLogic.resumeLabel(title, progress, hasLast));
        continueButton.setAlpha(hasLast ? 1f : .58f);
        continueButton.setContentDescription(hasLast
                ? "Resume " + title + " from " + time(progress)
                : "Resume Last Video — play a video first");
    }

    private void showVideoOptions(VideoRow video) {
        long saved = VideoResumeStore.get(this, video.uri.toString());
        String[] options = {"▶ Continue playback", "↺ Start from beginning", "ℹ Video details"};
        new AlertDialog.Builder(this)
                .setTitle(video.title)
                .setItems(options, (dialog, which) -> {
                    if (which == 0) openVideo(video, false);
                    else if (which == 1) openVideo(video, true);
                    else new AlertDialog.Builder(this)
                            .setTitle(video.title)
                            .setMessage("Folder: " + VideoFolderLogic.displayName(video.folder)
                                    + "\nDuration: " + time(video.duration)
                                    + "\nLast position: " + (VideoResumeLogic.shouldResume(saved, video.duration)
                                        ? time(saved) : "Not in progress"))
                            .setPositiveButton("OK", null).show();
                }).show();
    }

    private void reloadOrRequest() {
        if (hasVideoPermission()) reloadVideos();
        else askForVideoAccess();
    }

    private boolean hasFullAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasPartialAccess() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE &&
                checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
                        == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasVideoPermission() { return hasFullAccess() || hasPartialAccess(); }

    private void askForVideoAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            requestPermissions(new String[]{Manifest.permission.READ_MEDIA_VIDEO,
                    Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED}, REQUEST_VIDEO_ACCESS);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(new String[]{Manifest.permission.READ_MEDIA_VIDEO}, REQUEST_VIDEO_ACCESS);
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_VIDEO_ACCESS);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode != REQUEST_VIDEO_ACCESS) return;
        if (hasVideoPermission()) reloadVideos();
        else {
            allVideos.clear();
            visibleVideos.clear();
            folderItems.clear();
            visibleFolders.clear();
            adapter.notifyDataSetChanged();
            folderAdapter.notifyDataSetChanged();
            folderGridAdapter.notifyDataSetChanged();
            if (thumbnails != null) thumbnails.clear();
            status.setText("To show your phone's videos, allow video access. You can still use the system file picker.");
        }
    }

    @Override protected void onStart() {
        super.onStart();
        if (!observerRegistered) {
            try {
                Uri collection = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                        ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                        : MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                getContentResolver().registerContentObserver(collection, true, mediaChanges);
                observerRegistered = true;
            } catch (RuntimeException ignored) {
                // Normal onResume reload remains available when providers disallow observers.
            }
        }
    }

    @Override protected void onStop() {
        main.removeCallbacks(videoIndexChanged);
        if (observerRegistered) {
            getContentResolver().unregisterContentObserver(mediaChanges);
            observerRegistered = false;
        }
        super.onStop();
    }

    @Override protected void onResume() {
        super.onResume();
        // Only requery after returning from another screen, not immediately after onCreate.
        if (firstResume) {
            firstResume = false;
            return;
        }
        if (hasVideoPermission()) reloadVideos();
        else if (adapter != null) {
            // Don't retain a stale thumbnail / list after permission was revoked.
            allVideos.clear(); visibleVideos.clear(); folderItems.clear(); visibleFolders.clear();
            if (thumbnails != null) thumbnails.clear();
            applyFilters();
        }
        updateContinueButton();
    }

    private void reloadVideos() {
        if (!hasVideoPermission()) return;
        final int generation = ++loadNumber;
        status.setText("Scanning videos on your phone…");
        loader.execute(() -> {
            List<VideoRow> found = new ArrayList<>();
            String error = null;
            try {
                Uri collection = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                        ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                        : MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                String folderColumn = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                        ? MediaStore.MediaColumns.RELATIVE_PATH : MediaStore.Video.Media.DATA;
                String[] columns = {MediaStore.Video.Media._ID,
                        MediaStore.Video.Media.DISPLAY_NAME,
                        MediaStore.Video.Media.DURATION,
                        MediaStore.Video.Media.DATE_ADDED,
                        folderColumn};
                try (Cursor cursor = getContentResolver().query(collection, columns, null, null,
                        MediaStore.Video.Media.DATE_ADDED + " DESC")) {
                    if (cursor != null) {
                        int idIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID);
                        int nameIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME);
                        int durationIndex = cursor.getColumnIndex(MediaStore.Video.Media.DURATION);
                        int dateIndex = cursor.getColumnIndex(MediaStore.Video.Media.DATE_ADDED);
                        int folderIndex = cursor.getColumnIndex(folderColumn);
                        while (cursor.moveToNext()) {
                            long id = cursor.getLong(idIndex);
                            String title = cursor.getString(nameIndex);
                            long duration = durationIndex < 0 ? 0L : cursor.getLong(durationIndex);
                            long dateAdded = dateIndex < 0 ? 0L : cursor.getLong(dateIndex);
                            String path = folderIndex < 0 ? null : cursor.getString(folderIndex);
                            String folder = path == null || path.trim().isEmpty() ? "Other videos" : path;
                            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                                int slash = folder.lastIndexOf('/');
                                folder = slash > 0 ? folder.substring(0, slash) : "Other videos";
                            }
                            found.add(new VideoRow(ContentUris.withAppendedId(collection, id),
                                    title == null || title.trim().isEmpty() ? "Untitled video" : title,
                                    folder, Math.max(0L, duration), dateAdded));
                        }
                    }
                }
            } catch (SecurityException permission) {
                error = "Video permission changed. Tap Video Access to allow it again.";
            } catch (RuntimeException readError) {
                error = "Could not read the phone's video index. Try Refresh or select files manually.";
            }
            final String message = error;
            main.post(() -> {
                if (destroyed || generation != loadNumber) return;
                // A failed read must NOT initialize/overwrite the NEW-video baseline.
                if (message == null) {
                    List<String> videoUris = new ArrayList<>();
                    for (VideoRow video : found) videoUris.add(video.uri.toString());
                    VideoFreshnessStore.recordSuccessfulScan(this, videoUris);
                }
                allVideos.clear();
                allVideos.addAll(found);
                updateFolders();
                applyFilters();
                updateContinueButton();
                if (message != null) status.setText(message);
            });
        });
    }

    private void updateFolders() {
        Map<String, FolderSummary> byPath = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        for (VideoRow video : allVideos) {
            String path = VideoFolderLogic.folderKey(video.folder);
            FolderSummary folder = byPath.get(path);
            if (folder == null) {
                folder = new FolderSummary(path, VideoFolderLogic.displayName(path));
                byPath.put(path, folder);
            }
            folder.count++;
            long position = VideoResumeStore.get(this, video.uri.toString());
            if (VideoResumeLogic.shouldResume(position, video.duration)) folder.continueCount++;
            folder.newCount = VideoFreshnessLogic.folderNewCount(folder.newCount,
                    VideoFreshnessStore.isNew(this, video.uri.toString()));
        }
        folderItems.clear();
        folderItems.addAll(byPath.values());
    }

    private void applyFilters() {
        if (adapter == null || folderAdapter == null || search == null || status == null) return;
        String keyword = search.getText().toString().trim().toLowerCase(Locale.ROOT);
        if (mode == MODE_FOLDERS) {
            visibleFolders.clear();
            for (FolderSummary folder : folderItems) {
                if (keyword.isEmpty() || folder.name.toLowerCase(Locale.ROOT).contains(keyword)
                        || folder.path.toLowerCase(Locale.ROOT).contains(keyword)
                        || containsVideoMatch(folder.path, keyword)) {
                    visibleFolders.add(folder);
                }
            }
            folderAdapter.notifyDataSetChanged();
            folderGridAdapter.notifyDataSetChanged();
            status.setText(visibleFolders.size() + " folders  •  " + allVideos.size() + " videos"
                    + (hasPartialAccess() && !hasFullAccess() ? "  •  Selected access" : ""));
            return;
        }
        visibleVideos.clear();
        for (VideoRow video : allVideos) {
            if (mode == MODE_FOLDER_VIDEOS && !VideoFolderLogic.sameFolder(selectedFolder, video.folder)) continue;
            long saved = VideoResumeStore.get(this, video.uri.toString());
            if (mode == MODE_CONTINUE && !VideoResumeLogic.shouldResume(saved, video.duration)) continue;
            if (!keyword.isEmpty() && !video.title.toLowerCase(Locale.ROOT).contains(keyword)
                    && !video.folder.toLowerCase(Locale.ROOT).contains(keyword)) continue;
            visibleVideos.add(video);
        }
        int sorting = sortSpinner == null ? 0 : sortSpinner.getSelectedItemPosition();
        if (sorting == 1) Collections.sort(visibleVideos,
                Comparator.comparing(row -> row.title.toLowerCase(Locale.ROOT)));
        else if (sorting == 2) Collections.sort(visibleVideos, (a, b) -> Long.compare(b.duration, a.duration));
        else Collections.sort(visibleVideos, (a, b) -> Long.compare(b.dateAdded, a.dateAdded));
        adapter.notifyDataSetChanged();
        status.setText(visibleVideos.size() + " videos" +
                (hasPartialAccess() && !hasFullAccess() ? "  •  Selected access" : ""));
    }

    private boolean containsVideoMatch(String folderPath, String query) {
        for (VideoRow video : allVideos) {
            if (VideoFolderLogic.sameFolder(folderPath, video.folder)
                    && video.title.toLowerCase(Locale.ROOT).contains(query)) return true;
        }
        return false;
    }

    private View buildFolderView(int position, boolean grid) {
        FolderSummary folder = visibleFolders.get(position);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setOrientation(grid ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        row.setPadding(dp(12), dp(11), dp(12), dp(11));
        row.setBackground(background(Ui.CARD));
        TextView glyph = label("📁", grid ? 42 : 40, Ui.ACCENT, false);
        glyph.setGravity(Gravity.CENTER);
        glyph.setBackground(background(Ui.CARD_2));
        row.addView(glyph, new LinearLayout.LayoutParams(
                grid ? -1 : dp(90), grid ? dp(100) : dp(76)));
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                grid ? -1 : 0, -2, grid ? 0 : 1);
        if (!grid) labelParams.leftMargin = dp(12);
        else labelParams.topMargin = dp(9);
        row.addView(labels, labelParams);
        TextView name = label(folder.name, grid ? 14 : 17, Ui.TEXT, true);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        labels.addView(name);
        TextView count = label(folder.count + (folder.count == 1 ? " video" : " videos"), 13, Ui.MUTED, false);
        labels.addView(count);
        if (folder.newCount > 0) {
            TextView newVideos = label("● NEW  " + folder.newCount
                    + (folder.newCount == 1 ? " unseen video" : " unseen videos"),
                    12, 0xFFE53935, true);
            newVideos.setContentDescription(folder.newCount + " new unseen video(s) in " + folder.name);
            labels.addView(newVideos);
        }
        if (folder.continueCount > 0) {
            TextView watched = label("↺ " + folder.continueCount + " to continue", 11, Ui.ACCENT, false);
            labels.addView(watched);
        }
        return row;
    }

    private final class VideoFolderAdapter extends BaseAdapter {
        @Override public int getCount() { return visibleFolders.size(); }
        @Override public FolderSummary getItem(int pos) { return visibleFolders.get(pos); }
        @Override public long getItemId(int pos) { return getItem(pos).path.hashCode(); }
        @Override public View getView(int pos, View convert, ViewGroup parent) { return buildFolderView(pos, false); }
    }

    private final class VideoFolderGridAdapter extends BaseAdapter {
        @Override public int getCount() { return visibleFolders.size(); }
        @Override public FolderSummary getItem(int pos) { return visibleFolders.get(pos); }
        @Override public long getItemId(int pos) { return getItem(pos).path.hashCode(); }
        @Override public View getView(int pos, View convert, ViewGroup parent) { return buildFolderView(pos, true); }
    }

    private static final class FolderSummary {
        final String path, name;
        int count, continueCount, newCount;
        FolderSummary(String path, String name) { this.path = path; this.name = name; }
    }

    private TextView label(String text, int textSize, int color, boolean bold) {
        return Ui.text(this, text, textSize, color, bold);
    }
    private int dp(float v) { return Ui.dp(this, v); }
    private GradientDrawable background(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(14));
        return bg;
    }
    private String time(long ms) {
        long seconds = Math.max(0, ms) / 1000;
        long hours = seconds / 3600, minutes = (seconds % 3600) / 60;
        return hours > 0 ? String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds % 60)
                : String.format(Locale.US, "%02d:%02d", minutes, seconds % 60);
    }

    private final class VideoAdapter extends BaseAdapter {
        @Override public int getCount() { return visibleVideos.size(); }
        @Override public VideoRow getItem(int position) { return visibleVideos.get(position); }
        @Override public long getItemId(int position) { return getItem(position).uri.hashCode(); }
        @Override public View getView(int position, View convertView, ViewGroup parent) {
            RowHolder holder;
            if (convertView == null) {
                LinearLayout row = new LinearLayout(VideoLibraryActivity.this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(8), dp(9), dp(8), dp(9));
                row.setBackground(background(Ui.CARD));

                FrameLayout thumb = new FrameLayout(VideoLibraryActivity.this);
                thumb.setBackground(background(Ui.CARD_2));
                ImageView image = new ImageView(VideoLibraryActivity.this);
                image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                thumb.addView(image, new FrameLayout.LayoutParams(-1, -1));

                TextView placeholder = label("▶", 22, Ui.MUTED, true);
                placeholder.setGravity(Gravity.CENTER);
                thumb.addView(placeholder, new FrameLayout.LayoutParams(-1, -1));
                // Put the image on top of the placeholder; a transparent/failed thumbnail
                // falls back to the background instead of a stale image from another row.
                thumb.bringChildToFront(image);

                TextView duration = label("00:00", 11, Color.WHITE, true);
                duration.setPadding(dp(5), dp(1), dp(5), dp(1));
                GradientDrawable badge = new GradientDrawable();
                badge.setColor(0xD6000000);
                badge.setCornerRadius(dp(5));
                duration.setBackground(badge);
                FrameLayout.LayoutParams durationParams = new FrameLayout.LayoutParams(-2, -2,
                        Gravity.BOTTOM | Gravity.END);
                durationParams.bottomMargin = dp(4);
                durationParams.rightMargin = dp(4);
                thumb.addView(duration, durationParams);
                TextView newBadge = label("● NEW", 11, Color.WHITE, true);
                newBadge.setPadding(dp(5), dp(2), dp(5), dp(2));
                GradientDrawable newBackground = new GradientDrawable();
                newBackground.setColor(0xFFE53935);
                newBackground.setCornerRadius(dp(5));
                newBadge.setBackground(newBackground);
                FrameLayout.LayoutParams newParams = new FrameLayout.LayoutParams(-2, -2,
                        Gravity.TOP | Gravity.START);
                newParams.topMargin = dp(5);
                newParams.leftMargin = dp(5);
                thumb.addView(newBadge, newParams);
                row.addView(thumb, new LinearLayout.LayoutParams(dp(128), dp(76)));

                LinearLayout details = new LinearLayout(VideoLibraryActivity.this);
                details.setOrientation(LinearLayout.VERTICAL);
                TextView title = label("", 15, Ui.TEXT, false);
                title.setMaxLines(3);
                title.setEllipsize(TextUtils.TruncateAt.END);
                TextView resume = label("", 12, Ui.ACCENT, false);
                LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(-1, -2);
                progressParams.topMargin = dp(5);
                details.addView(title);
                details.addView(resume, progressParams);
                LinearLayout.LayoutParams detailParams = new LinearLayout.LayoutParams(0, -2, 1);
                detailParams.leftMargin = dp(12);
                row.addView(details, detailParams);

                TextView more = label("⋮", 25, Ui.MUTED, true);
                more.setGravity(Gravity.CENTER);
                more.setContentDescription("Video options");
                more.setClickable(true);
                more.setFocusable(false);
                row.addView(more, new LinearLayout.LayoutParams(dp(40), dp(60)));
                holder = new RowHolder(row, image, duration, newBadge, title, resume, more);
                row.setTag(holder);
                convertView = row;
            } else {
                holder = (RowHolder) convertView.getTag();
            }
            VideoRow video = getItem(position);
            holder.title.setText(video.title);
            holder.duration.setText(time(video.duration));
            long saved = VideoResumeStore.get(VideoLibraryActivity.this, video.uri.toString());
            boolean canResume = VideoResumeLogic.shouldResume(saved, video.duration);
            holder.resume.setText(canResume ? "↺ Continue from " + time(saved) : "");
            boolean newVideo = VideoFreshnessStore.isNew(VideoLibraryActivity.this,
                    video.uri.toString());
            holder.newBadge.setVisibility(newVideo ? View.VISIBLE : View.GONE);
            holder.newBadge.setContentDescription(newVideo ? "New video, not yet played" : "");
            holder.more.setContentDescription("More options for " + video.title);
            holder.more.setOnClickListener(v -> showVideoOptions(video));
            holder.row.setOnClickListener(v -> openVideo(video, false));
            thumbnails.load(holder.thumbnail, video.uri);
            return convertView;
        }
    }

    private static final class RowHolder {
        final LinearLayout row;
        final ImageView thumbnail;
        final TextView duration, newBadge, title, resume, more;
        RowHolder(LinearLayout row, ImageView thumbnail, TextView duration, TextView newBadge,
                  TextView title, TextView resume, TextView more) {
            this.row = row;
            this.thumbnail = thumbnail;
            this.duration = duration;
            this.newBadge = newBadge;
            this.title = title;
            this.resume = resume;
            this.more = more;
        }
    }

    private static final class VideoRow {
        final Uri uri;
        final String title, folder;
        final long duration, dateAdded;
        VideoRow(Uri uri, String title, String folder, long duration, long dateAdded) {
            this.uri = uri; this.title = title; this.folder = folder;
            this.duration = duration; this.dateAdded = dateAdded;
        }
    }

    @Override protected void onDestroy() {
        destroyed = true;
        main.removeCallbacks(videoIndexChanged);
        ++loadNumber;
        loader.shutdownNow();
        if (thumbnails != null) thumbnails.shutdown();
        super.onDestroy();
    }
}
