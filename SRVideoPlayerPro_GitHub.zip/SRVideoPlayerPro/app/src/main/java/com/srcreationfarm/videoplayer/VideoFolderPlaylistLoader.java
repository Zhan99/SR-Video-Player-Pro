package com.srcreationfarm.videoplayer;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import java.util.ArrayList;
import java.util.List;

/** Reads accessible MediaStore video records off the UI thread, returning one folder's queue. */
public final class VideoFolderPlaylistLoader {
    private VideoFolderPlaylistLoader() {}

    public static List<VideoFolderQueueLogic.Entry> readFolder(ContentResolver resolver,
            String folder, String search, int sortMode) {
        List<VideoFolderQueueLogic.Entry> discovered = new ArrayList<>();
        Uri collection = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                : MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        String folderColumn = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                ? MediaStore.MediaColumns.RELATIVE_PATH : MediaStore.Video.Media.DATA;
        String[] columns = {MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DURATION, MediaStore.Video.Media.DATE_ADDED,
                MediaStore.Video.Media.MIME_TYPE, folderColumn};
        try (Cursor cursor = resolver.query(collection, columns, null, null,
                MediaStore.Video.Media.DATE_ADDED + " DESC")) {
            if (cursor == null) return discovered;
            int idIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID);
            int titleIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME);
            int lengthIndex = cursor.getColumnIndex(MediaStore.Video.Media.DURATION);
            int dateIndex = cursor.getColumnIndex(MediaStore.Video.Media.DATE_ADDED);
            int folderIndex = cursor.getColumnIndex(folderColumn);
            int mimeIndex = cursor.getColumnIndex(MediaStore.Video.Media.MIME_TYPE);
            while (cursor.moveToNext()) {
                long id = cursor.getLong(idIndex);
                String title = cursor.getString(titleIndex);
                long duration = lengthIndex < 0 ? 0L : cursor.getLong(lengthIndex);
                long date = dateIndex < 0 ? 0L : cursor.getLong(dateIndex);
                String path = folderIndex < 0 ? null : cursor.getString(folderIndex);
                String currentFolder = path == null || path.trim().isEmpty() ? "Other videos" : path;
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    int slash = currentFolder.lastIndexOf('/');
                    currentFolder = slash > 0 ? currentFolder.substring(0, slash) : "Other videos";
                }
                // Filter as we scan to reduce memory for large phone libraries.
                if (!VideoFolderLogic.sameFolder(folder, currentFolder)) continue;
                String uri = ContentUris.withAppendedId(collection, id).toString();
                String mime = mimeIndex < 0 ? null : cursor.getString(mimeIndex);
                discovered.add(new VideoFolderQueueLogic.Entry(uri,
                        title == null || title.trim().isEmpty() ? "Untitled video" : title,
                        currentFolder, Math.max(0L, duration), date, mime));
            }
        }
        return VideoFolderQueueLogic.filterAndOrder(discovered, folder, search, sortMode);
    }
}
