package com.srcreationfarm.videoplayer;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;

/** Handles the exact URI received through Open With / Android Sharesheet. */
final class ExternalVideoIntent {
    private ExternalVideoIntent() { }
    static Uri uriFrom(Intent intent) {
        if (intent == null) return null;
        String action = intent.getAction();
        if (Intent.ACTION_VIEW.equals(action)) {
            return intent.getData();
        }
        if (Intent.ACTION_SEND.equals(action)) {
            Parcelable item = Build.VERSION.SDK_INT >= 33
                    ? intent.getParcelableExtra(Intent.EXTRA_STREAM, Parcelable.class)
                    : intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (item instanceof Uri) return (Uri) item;
            if (intent.getClipData() != null && intent.getClipData().getItemCount() > 0) {
                return intent.getClipData().getItemAt(0).getUri();
            }
        }
        return null;
    }
    static boolean playableScheme(String scheme) {
        return ExternalVideoPolicy.playableScheme(scheme);
    }
    static String bestTitle(Intent intent, Uri uri) {
        String given = intent.getStringExtra(Intent.EXTRA_TITLE);
        if (given != null && !given.trim().isEmpty()) return given.trim();
        if (uri == null) return "Video";
        String segment = uri.getLastPathSegment();
        return segment == null || segment.isEmpty() ? "Video" : segment;
    }
}
