package com.srcreationfarm.videoplayer;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Pure Java folder-scoped playlist ordering: no videos from neighbouring folders. */
public final class VideoFolderQueueLogic {
    private VideoFolderQueueLogic() {}

    public static final class Entry {
        public final String uri;
        public final String title;
        public final String folder;
        public final long duration;
        public final long dateAdded;
        public final String mimeType;

        public Entry(String uri, String title, String folder, long duration, long dateAdded) {
            this(uri, title, folder, duration, dateAdded, null);
        }

        public Entry(String uri, String title, String folder, long duration,
                     long dateAdded, String mimeType) {
            this.uri = uri == null ? "" : uri;
            this.title = title == null ? "Untitled video" : title;
            this.folder = folder;
            this.duration = duration;
            this.dateAdded = dateAdded;
            this.mimeType = mimeType;
        }
    }

    /** sortMode matches the library: 0 newest, 1 title A-Z, 2 longest. */
    public static List<Entry> filterAndOrder(List<Entry> available, String folder,
                                             String search, int sortMode) {
        List<Entry> results = new ArrayList<>();
        if (available == null || folder == null || folder.trim().isEmpty()) return results;
        String needle = search == null ? "" : search.trim().toLowerCase(Locale.ROOT);
        for (Entry entry : available) {
            if (entry == null || entry.uri.isEmpty() || !VideoFolderLogic.sameFolder(folder, entry.folder)) {
                continue;
            }
            if (!needle.isEmpty() && !entry.title.toLowerCase(Locale.ROOT).contains(needle)
                    && !(entry.folder != null && entry.folder.toLowerCase(Locale.ROOT).contains(needle))) {
                continue;
            }
            results.add(entry);
        }
        Comparator<Entry> order;
        if (sortMode == 1) order = Comparator.comparing(e -> e.title.toLowerCase(Locale.ROOT));
        else if (sortMode == 2) order = (a, b) -> Long.compare(b.duration, a.duration);
        else order = (a, b) -> Long.compare(b.dateAdded, a.dateAdded);
        // Equal keys preserve the MediaStore scan order, exactly as the library list does.
        results.sort(order);
        return results;
    }

    public static int indexOf(List<Entry> entries, String selectedUri) {
        if (entries == null || selectedUri == null) return -1;
        for (int i = 0; i < entries.size(); ++i) {
            if (selectedUri.equals(entries.get(i).uri)) return i;
        }
        return -1;
    }

    public static int adjacentIndex(int current, int count, boolean next) {
        if (count <= 0 || current < 0 || current >= count) return -1;
        return next ? Math.min(count - 1, current + 1) : Math.max(0, current - 1);
    }
}
