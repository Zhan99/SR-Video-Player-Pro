package com.srcreationfarm.videoplayer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.view.Gravity;

/** Independent app landing page; no unrelated Toolbox features or permissions. */
public final class VideoHomeActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        ThemeManager.applyToActivity(this);
        super.onCreate(state);
        setContentView(buildPage());
    }
    @Override protected void onResume() {
        super.onResume();
        ThemeManager.initialize(this);
    }
    private LinearLayout buildPage() {
        LinearLayout root=Ui.page(this, "SR Video Player Pro");
        LinearLayout content=Ui.content(root);
        LinearLayout hero=Ui.card(this);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        hero.addView(logo, new LinearLayout.LayoutParams(-1, Ui.dp(this,108)));
        TextView title=Ui.text(this, "▶  SR VIDEO PLAYER PRO",22,Ui.ACCENT,true);
        title.setGravity(Gravity.CENTER);
        hero.addView(title);
        TextView sub=Ui.text(this, "Premium video experience • Offline library • 4× zoom",13,Ui.MUTED,false);
        sub.setGravity(Gravity.CENTER);
        hero.addView(sub);
        Ui.addCard(this,content,hero,12);
        add(content,"📁  Browse all video folders",()->startActivity(new Intent(this,VideoLibraryActivity.class)));
        add(content,"🎬  Open a video file",()->player(VideoPlayerActivity.EXTRA_OPEN_PICKER));
        add(content,"↺  Continue last video",()->player(VideoPlayerActivity.EXTRA_CONTINUE_LAST));
        add(content,"⚙  Video player & theme settings",()->startActivity(new Intent(this,ThemeSettingsActivity.class)));
        add(content,"⭐  Set as default video player",this::openDefaultSettings);
        add(content,"ℹ  About Developer",()->startActivity(new Intent(this,AboutDeveloperActivity.class)));
        Ui.addText(this,content,"GESTURES",13,Ui.ACCENT,true,24);
        Ui.addText(this,content,"Two-finger pinch: 1×–4× zoom  •  Press & hold: 1.5×–4× speed  •  Double-tap: ±10 seconds  •  Side swipe: brightness / volume.",13,Ui.MUTED,false,5);
        Ui.addText(this,content,"Created by Shahriar Rahman  •  SR Creation Farm",12,Ui.MUTED,false,18);
        return root;
    }
    private void add(LinearLayout content,String title,Runnable action) {
        Button b=Ui.button(this,title,action);
        Ui.addCard(this,content,b,11);
    }
    private void player(String mode) {
        startActivity(new Intent(this,VideoPlayerActivity.class).putExtra(mode,true));
    }
    private void openDefaultSettings() {
        new AlertDialog.Builder(this)
                .setTitle("Default video player")
                .setMessage("ফোনের File Manager / Gallery থেকে একটি ভিডিও নির্বাচন করুন → Open with → SR Video Player Pro → Always (যদি অপশন থাকে)।\n\nAndroid-এর সব মডেলে আলাদা Video Player Default Settings থাকে না।")
                .setPositiveButton("App Settings",(d,w)->{
                    try {
                        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:"+getPackageName())));
                    } catch (RuntimeException ex) {
                        startActivity(new Intent(Settings.ACTION_SETTINGS));
                    }
                })
                .setNegativeButton("Close",null)
                .show();
    }
}
