package com.srcreationfarm.videoplayer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/** Legacy entry retained for package compatibility; always open the folder home. */
public final class VideoHomeActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        startActivity(new Intent(this, VideoLibraryActivity.class));
        finish();
    }
}
