package com.srcreationfarm.videoplayer;
import android.app.Application;
public final class SrVideoApp extends Application {
    @Override public void onCreate() {
        super.onCreate();
        ThemeManager.initialize(this);
        UiSound.preload(this);
    }
}
