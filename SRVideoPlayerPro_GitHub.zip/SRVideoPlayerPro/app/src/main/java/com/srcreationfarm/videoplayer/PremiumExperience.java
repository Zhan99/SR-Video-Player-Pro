package com.srcreationfarm.videoplayer;

import android.content.Context;
import android.content.SharedPreferences;

/** Separate from palette preferences: switching to Classic never loses the old look. */
final class PremiumExperience {
    private static final String PREFS = "sr_premium_experience_v1";
    private static final String STYLE = "interface_style";
    private static final String SOUND = "interface_sound_enabled";
    private static final String PACK = "interface_sound_pack";
    private static final String MOTION = "interface_motion_enabled";
    private PremiumExperience() { }
    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    static int style(Context c) { return PremiumExperienceLogic.style(prefs(c).getInt(STYLE, PremiumExperienceLogic.PREMIUM)); }
    static boolean premium(Context c) { return style(c) == PremiumExperienceLogic.PREMIUM; }
    static void setStyle(Context c, int value) { prefs(c).edit().putInt(STYLE, PremiumExperienceLogic.style(value)).apply(); }
    static boolean sounds(Context c) { return prefs(c).getBoolean(SOUND, true); }
    static void setSounds(Context c, boolean enabled) { prefs(c).edit().putBoolean(SOUND, enabled).apply(); }
    static int pack(Context c) { return PremiumExperienceLogic.soundPack(prefs(c).getInt(PACK, PremiumExperienceLogic.SOFT)); }
    static void setPack(Context c, int pack) { prefs(c).edit().putInt(PACK, PremiumExperienceLogic.soundPack(pack)).apply(); }
    static boolean motion(Context c) { return prefs(c).getBoolean(MOTION, true); }
    static void setMotion(Context c, boolean enabled) { prefs(c).edit().putBoolean(MOTION, enabled).apply(); }
}
