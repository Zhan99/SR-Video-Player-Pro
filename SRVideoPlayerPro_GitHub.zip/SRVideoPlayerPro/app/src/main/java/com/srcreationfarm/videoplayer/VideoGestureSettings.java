package com.srcreationfarm.videoplayer;

import android.content.Context;
import android.content.SharedPreferences;

/** User-configured instant fast-forward while the video surface is pressed. */
final class VideoGestureSettings {
    private static final String PREFS = "sr_video_gesture_settings";
    private static final String KEY_HOLD_SPEED = "hold_speed";
    static final float[] OPTIONS = {1.5f, 2f, 2.5f, 3f, 4f};
    private VideoGestureSettings() {}
    static float holdSpeed(Context context) {
        return VideoZoomLogic.acceptedHoldSpeed(context.getSharedPreferences(PREFS,
                Context.MODE_PRIVATE).getFloat(KEY_HOLD_SPEED, 2f));
    }
    static void saveHoldSpeed(Context context, float speed) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putFloat(KEY_HOLD_SPEED, VideoZoomLogic.acceptedHoldSpeed(speed)).apply();
    }
}
