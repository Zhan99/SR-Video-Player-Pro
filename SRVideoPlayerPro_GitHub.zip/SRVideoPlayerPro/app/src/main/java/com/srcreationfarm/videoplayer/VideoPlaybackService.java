package com.srcreationfarm.videoplayer;

import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.util.UnstableApi;
import android.os.Handler;
import android.os.Looper;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

@UnstableApi
public class VideoPlaybackService extends MediaSessionService {
    private static volatile VideoPlaybackService activeInstance;
    private final Handler serviceHandler = new Handler(Looper.getMainLooper());
    private Runnable sleepStopRunnable;
    private ExoPlayer player;
    private MediaSession mediaSession;

    public static boolean scheduleSleepTimer(long delayMs) {
        VideoPlaybackService service = activeInstance;
        if (service == null || service.player == null || delayMs <= 0) return false;
        service.cancelSleepTimerInternal();
        service.sleepStopRunnable = () -> {
            if (service.player != null) {
                service.player.pause();
                service.player.stop();
                service.player.clearMediaItems();
            }
            service.sleepStopRunnable = null;
        };
        service.serviceHandler.postDelayed(service.sleepStopRunnable, delayMs);
        return true;
    }

    public static void cancelSleepTimer() {
        VideoPlaybackService service = activeInstance;
        if (service != null) service.cancelSleepTimerInternal();
    }

    /** Explicit Back stops playback even if the Activity's controller is still connecting. */
    public static void stopCurrentPlayback() {
        VideoPlaybackService service = activeInstance;
        if (service == null) return;
        service.serviceHandler.post(() -> {
            if (service.player == null) return;
            service.cancelSleepTimerInternal();
            service.player.pause();
            service.player.stop();
            service.player.clearMediaItems();
        });
    }

    private void cancelSleepTimerInternal() {
        if (sleepStopRunnable != null) {
            serviceHandler.removeCallbacks(sleepStopRunnable);
            sleepStopRunnable = null;
        }
    }

    @Override public void onCreate() {
        super.onCreate();
        activeInstance = this;
        DefaultTrackSelector selector = new DefaultTrackSelector(this);
        player = new ExoPlayer.Builder(this)
                .setTrackSelector(selector)
                .setWakeMode(C.WAKE_MODE_LOCAL)
                .setHandleAudioBecomingNoisy(true)
                .build();
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build();
        player.setAudioAttributes(audioAttributes, true);
        mediaSession = new MediaSession.Builder(this, player).build();
    }

    @Override public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) {
        return mediaSession;
    }

    @Override public void onDestroy() {
        cancelSleepTimerInternal();
        if (activeInstance == this) activeInstance = null;
        if (mediaSession != null) {
            mediaSession.release();
            mediaSession = null;
        }
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
