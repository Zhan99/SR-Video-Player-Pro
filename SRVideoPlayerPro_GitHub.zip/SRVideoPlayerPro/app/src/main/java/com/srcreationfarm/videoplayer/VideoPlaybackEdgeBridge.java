package com.srcreationfarm.videoplayer;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

/** In-player portrait edge handle; not a system-wide Toolbox overlay. */
public final class VideoPlaybackEdgeBridge {
    private static VideoPlayerActivity active;
    private static View edge;
    private VideoPlaybackEdgeBridge() { }

    public static void onPlaying(Context context) {
        if (!(context instanceof VideoPlayerActivity)) return;
        VideoPlayerActivity player = (VideoPlayerActivity) context;
        if (context.getResources().getConfiguration().orientation
                != Configuration.ORIENTATION_PORTRAIT) return;
        if (active == player && edge != null) return;
        onStopped(context);
        FrameLayout host = player.findViewById(android.R.id.content);
        if (host == null) return;
        TextView bar = new TextView(player);
        bar.setText("❯");
        bar.setTextColor(Color.WHITE);
        bar.setTextSize(19);
        bar.setGravity(Gravity.CENTER);
        bar.setContentDescription("Show video playback controls");
        int density = (int) (player.getResources().getDisplayMetrics().density * 1.0f + .5f);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xE92A364D);
        bg.setStroke(Math.max(1,density),0xFFFFC247);
        bg.setCornerRadii(new float[]{12f*density,12f*density,0,0,0,0,12f*density,12f*density});
        bar.setBackground(bg);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(24*density,84*density,
                Gravity.END | Gravity.CENTER_VERTICAL);
        bar.setOnClickListener(v -> player.revealControlsFromEdge());
        host.addView(bar,lp);
        edge=bar; active=player;
    }

    public static void onStopped(Context context) {
        if (edge != null && active != null) {
            try {
                if (edge.getParent() instanceof ViewGroup)
                    ((ViewGroup) edge.getParent()).removeView(edge);
            } catch (RuntimeException ignored) { }
        }
        edge=null; active=null;
    }
}
