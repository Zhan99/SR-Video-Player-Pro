package com.srcreationfarm.videoplayer;

/** A new video is one discovered after the first library scan and not played in SR. */
public final class VideoFreshnessLogic {
    private VideoFreshnessLogic() {}
    public static boolean markNew(boolean libraryWasInitialized,
                                  boolean previouslyKnown, boolean alreadyWatched) {
        return libraryWasInitialized && !previouslyKnown && !alreadyWatched;
    }
    public static int folderNewCount(int currentCount, boolean hasUnreadNewVideo) {
        return hasUnreadNewVideo ? Math.max(0, currentCount) + 1 : Math.max(0, currentCount);
    }
}
