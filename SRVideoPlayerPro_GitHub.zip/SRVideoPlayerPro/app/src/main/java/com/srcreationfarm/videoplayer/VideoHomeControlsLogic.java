package com.srcreationfarm.videoplayer;

/** Pure Java launcher Resume policy; no Android dependency. */
public final class VideoHomeControlsLogic {
    private VideoHomeControlsLogic() {}

    public static boolean hasLastVideo(String uri) {
        return uri != null && !uri.trim().isEmpty();
    }

    public static String resumeLabel(String title, long savedPositionMs, boolean playable) {
        if (!playable) return "▶  Resume Last Video · Play a video first";
        String safeTitle = title == null ? "" : title.trim().replace('\n', ' ').replace('\r', ' ');
        if (safeTitle.isEmpty()) safeTitle = "Last watched video";
        if (safeTitle.length() > 60) safeTitle = safeTitle.substring(0, 57) + "…";
        return "▶  Resume · " + safeTitle + " · " + timeLabel(savedPositionMs);
    }

    public static String timeLabel(long ms) {
        long seconds = Math.max(0L, ms) / 1000L;
        long hr = seconds / 3600L, min = (seconds / 60L) % 60L, sec = seconds % 60L;
        if (hr > 0L) return String.format(java.util.Locale.US, "%d:%02d:%02d", hr, min, sec);
        return String.format(java.util.Locale.US, "%02d:%02d", min, sec);
    }
}
