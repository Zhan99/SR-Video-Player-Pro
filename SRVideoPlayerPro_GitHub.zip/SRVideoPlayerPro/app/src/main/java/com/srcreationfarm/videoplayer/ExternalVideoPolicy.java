package com.srcreationfarm.videoplayer;
/** Validates external file URI schemes without Android dependencies. */
public final class ExternalVideoPolicy {
    private ExternalVideoPolicy() { }
    public static boolean playableScheme(String scheme) {
        if (scheme == null) return false;
        return "content".equalsIgnoreCase(scheme) || "file".equalsIgnoreCase(scheme)
                || "https".equalsIgnoreCase(scheme) || "rtsp".equalsIgnoreCase(scheme);
    }
    public static boolean safeVideoMime(String mime) {
        if (mime == null) return false;
        String type = mime.toLowerCase(java.util.Locale.ROOT).trim();
        return type.startsWith("video/") || "application/x-matroska".equals(type)
                || "application/vnd.apple.mpegurl".equals(type)
                || "application/octet-stream".equals(type)
                || "application/x-mpegurl".equals(type)
                || "application/dash+xml".equals(type)
                || "application/vnd.ms-sstr+xml".equals(type);
    }
}
