package com.srcreationfarm.videoplayer;

/** Pure Java zoom and temporary playback-speed constraints. */
public final class VideoZoomLogic {
    public static final float MIN_ZOOM = 1f;
    public static final float MAX_ZOOM = 4f;
    private VideoZoomLogic() {}
    public static float zoom(float oldScale, float multiplier) {
        if (!Float.isFinite(oldScale) || !Float.isFinite(multiplier) || multiplier <= 0f) {
            return MIN_ZOOM;
        }
        return Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, oldScale * multiplier));
    }
    public static float acceptedHoldSpeed(float value) {
        if (!Float.isFinite(value)) return 2f;
        for (float option : new float[]{1.5f, 2f, 2.5f, 3f, 4f}) {
            if (Math.abs(option - value) < 0.001f) return option;
        }
        return 2f;
    }
    public static boolean canStartHold(boolean locked, boolean zooming, boolean playing,
                                       boolean hasVideo) {
        return !locked && !zooming && playing && hasVideo;
    }
}
