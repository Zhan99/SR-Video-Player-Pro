# SR Video Player Pro — সম্পূর্ণ আলাদা Android অ্যাপ

**Developer:** Shahriar Rahman  •  **Brand:** SR Creation Farm

এটি SR Smart Toolbox Pro v1.5.22-alpha48-এর **সরাসরি Video Player implementation থেকে** আলাদা করা standalone Android project। আলাদা Application ID `com.srcreationfarm.videoplayer` ব্যবহার করে। Toolbox-এর পুরোনো APK আনইনস্টল করতে হবে না।

## ভিডিও প্লেয়ারের সংরক্ষিত ফিচার

- Video Library: ফোনের Folder, All Videos, Continue Watching, Search, Sort, Thumbnail, Grid/List View এবং Refresh।
- প্রথম সফল Library Scan-কে পুরোনো তালিকা ধরে তারপর নতুন Video / Folder-এ লাল NEW Badge। নিজস্ব Player-এ Play হলে NEW মুছে যায়।
- Player: Media3 ExoPlayer, Play/Pause, Seek/Progress, Playlist/Queue, Repeat, Speed, Double Tap ±10 seconds, brightness ও volume gesture, screen lock, orientation, full screen ও picture-in-picture।
- Two finger Pinch Zoom 1×–4×; Hold-to-Fast Speed 1.5×/2×/2.5×/3×/4× (মেনুতে পরিবর্তনযোগ্য)।
- SRT, VTT, ASS/SSA, TTML external subtitle file, subtitle/audio track নির্বাচন, video screenshot, Favorites, History, Sleep Timer, Video Resume এবং Background Audio / media session notification।
- HTTPS / RTSP network URL, HLS, DASH, SmoothStreaming playback (সমর্থিত ফরম্যাট এবং ফোনের decoder অনুযায়ী)।
- ৯টি Theme Palette, Premium/Classic UI, User-selectable Light/Dark/System Appearance এবং optional UI Sounds।
- Portrait Player-এর ভিতরে edge handle রাখা হয়েছে, এটি চাপলে Playback Controls দেখা যায়। Toolbox-এর System-Wide Floating Toolbox কপি করা হয়নি, কারণ সেটি ভিডিও প্লেয়ারের নিজস্ব অংশ নয়।
- আলাদা লঞ্চার এবং Android Open With (`ACTION_VIEW`, `ACTION_SEND`, `video/*`), File Manager/Gallery থেকে ভিডিও Play।

## ফোনে ডিফল্ট ভিডিও প্লেয়ার করা

১. GitHub Actions থেকে Debug APK ডাউনলোড করে Install করুন।
২. File Manager বা Gallery-তে ভিডিওতে চাপ দিন। প্রয়োজনে **Open with** নির্বাচন করুন।
৩. তালিকা থেকে **SR Video Player Pro** বেছে নিন; ফোন অপশন দিলে **Always** নির্বাচন করুন।
৪. Android UI/নির্মাতাভেদে সব ডিভাইসে আলাদা Video Player Default নির্বাচন নাও থাকতে পারে। Video MIME বা File Provider-এর ধরন অনুযায়ী অন্য অ্যাপের সাথে Chooser-এ দেখাতে পারে। 

## GitHub-এ Build

এই ZIP `SRVideoPlayerPro_GitHub.zip`-এ একটিই Android project `SRVideoPlayerPro/` আছে। Repo root-এ এটি আপলোড করে `.github/workflows/build-apk.yml` রাখুন। Commit → Actions → Build SR Video Player Pro APK → Run workflow → Artifacts → SR-Video-Player-Pro-APK।

অথবা `SR-Video-Player-Pro-main.zip` এক্সট্রাক্ট করে এর ভিতরের সোর্স ZIP ও `.github/workflows/build-apk.yml` GitHub-এ আপলোড করতে পারেন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা

- Android 13+ এ পূর্ণ ফোন-ভিডিও Library দেখাতে READ_MEDIA_VIDEO অনুমতি লাগতে পারে; Android 14+ এ Partial Photo/Video অনুমতি দিলে শুধু অনুমোদিত ভিডিও পাওয়া যেতে পারে। Open With ব্যবহার করা ভিডিওতে সাধারণত Library Permission লাগে না।
- External content:// URI-র permission প্রদানকারীর ওপর নির্ভর করে। Sharing App অনুমতি প্রত্যাহার করলে Resume বা Background Playback-এর জন্য ভিডিওটি পুনরায় নির্বাচন করতে হতে পারে।
- DRM-protected বা ফোনে codec না থাকা ভিডিও সবসময় চলবে না।
- পুরোনো Toolbox-এর Private App Data (history/bookmarks/preferences) নতুন অ্যাপে স্বয়ংক্রিয়ভাবে আসবে না; package ID আলাদা।
- Source/Logic পরীক্ষা APK Build নয়। প্রকৃত Android APK GitHub Actions-এর Gradle/SDK দিয়ে তৈরি করতে হবে।
